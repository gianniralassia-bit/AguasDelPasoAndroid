module.exports = { content: ['./www/index.html'], theme: { extend: { colors: { brand: { blue: '#0284c7', 'blue-dark': '#0369a1', orange: '#f97316', 'orange-dark': '#ea580c' } } } }, plugins: [] };
